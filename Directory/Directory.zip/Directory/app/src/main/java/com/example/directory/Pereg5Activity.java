package com.example.directory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Pereg5Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pereg5);
    }
    public void startNewActivite(View v){
        Intent intent = new Intent(this,PhilmActivity.class);
        startActivity(intent);

    }
    public void goBacK(View v){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);

    }

}